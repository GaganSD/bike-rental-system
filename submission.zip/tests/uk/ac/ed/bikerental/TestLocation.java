package uk.ac.ed.bikerental;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;

class TestLocation {
    @BeforeEach
    void setUp() throws Exception {
        // TODO: setup some resources before each test
    }
    
    // TODO: put some tests here
}
