package uk.ac.ed.bikerental;


public class CustomerBookingInfo {

    public String firstName;
    public String phoneNum;
    public String postCode;
    public String address;
    public String surname;
    public String collectionMethod;


    public CustomerBookingInfo(String firstName,String phoneNum,
                String postCode, String address,String surname,String collectionMethod) {

        this.firstName = firstName;
        this.phoneNum = phoneNum;
        this.postCode = postCode;
        this.address = address;
        this.surname = surname;
        this.collectionMethod = collectionMethod;
    }
}