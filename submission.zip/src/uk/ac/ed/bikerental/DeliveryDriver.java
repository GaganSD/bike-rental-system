public class DeliveryDriver {

    public String uuid;


    public DeliveryDriver(String uuid) {
        this.uuid = uuid;
    }
}