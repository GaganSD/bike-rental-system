package uk.ac.ed.bikerental;

import java.util.Collection;
import java.util.Map;

public class BikeProvider {

    private String name;
    private Location location;
    private String phoneNumber;
    private String openingHours;
    private Collection<Bike> bikes;
    private Collection<BikeProvider> partners;
    // private Collection<DeliveryDriver> drivers;
    private Map<BikeType, Integer> rentalPrice;
    private Map<BikeType, Map<String, Integer>> depositPolicy;

    // constructor with only fields relevant to testing
    public BikeProvider(Location location, Collection<Bike> bikes) {
        this.location = location;
        this.bikes = bikes;
    }

    public Location getLocation() {
        return this.location;
    }

    public Collection<Bike> getBikes() {
        return this.bikes;
    }

    public void addBike(Bike bike) {
        bikes.add(bike);
    }

    public void registerOriginalBikeReturn(String serialNo) {
        // TODO: implement this method

        return;
    }

    public void registerPartnerBikeReturn(String serialNo) {
        // TODO: implement this method

        return;
    }

}