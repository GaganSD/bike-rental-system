package uk.ac.ed.bikerental;

import java.util.Collection;

public class Bike {
    private String serialNum;
    private BikeType bikeType;
    private Collection<Booking> bookings;

    public Bike(String serialNum, BikeType bikeType) {
        this.serialNum = serialNum;
        this.bikeType = bikeType;
    }

    public BikeType getBikeType() {
        return this.bikeType;
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
    }

    public Boolean isAvailable(DateRange dr) {
        return false;
    }

}